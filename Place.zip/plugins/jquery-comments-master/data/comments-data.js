var commentsArray = [  

]

var usersArray = [
   
      
]