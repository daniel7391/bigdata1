package gazua.model;

public class ReviewSupport {
	private int verygood;
	private int good;
	private int soso;
	private int bad;
	private int family;
	private int couple;
	private int friend;
	private int solo;
	private int spring;
	private int summer;
	private int autumn;
	private int winter;
	public int getVerygood() {
		return verygood;
	}
	public void setVerygood(int verygood) {
		this.verygood = verygood;
	}
	public int getGood() {
		return good;
	}
	public void setGood(int good) {
		this.good = good;
	}
	public int getSoso() {
		return soso;
	}
	public void setSoso(int soso) {
		this.soso = soso;
	}
	public int getBad() {
		return bad;
	}
	public void setBad(int bad) {
		this.bad = bad;
	}
	public int getFamily() {
		return family;
	}
	public void setFamily(int family) {
		this.family = family;
	}
	public int getCouple() {
		return couple;
	}
	public void setCouple(int couple) {
		this.couple = couple;
	}
	public int getFriend() {
		return friend;
	}
	public void setFriend(int friend) {
		this.friend = friend;
	}
	public int getSolo() {
		return solo;
	}
	public void setSolo(int solo) {
		this.solo = solo;
	}
	public int getSpring() {
		return spring;
	}
	public void setSpring(int spring) {
		this.spring = spring;
	}
	public int getSummer() {
		return summer;
	}
	public void setSummer(int summer) {
		this.summer = summer;
	}
	public int getAutumn() {
		return autumn;
	}
	public void setAutumn(int autumn) {
		this.autumn = autumn;
	}
	public int getWinter() {
		return winter;
	}
	public void setWinter(int winter) {
		this.winter = winter;
	}
	@Override
	public String toString() {
		return "ReviewSupport [verygood=" + verygood + ", good=" + good + ", soso=" + soso + ", bad=" + bad
				+ ", family=" + family + ", couple=" + couple + ", friend=" + friend + ", solo=" + solo + ", spring="
				+ spring + ", summer=" + summer + ", autumn=" + autumn + ", winter=" + winter + "]";
	}
	
	
}
